source ${0:A:h}/zsh-vi-mode.zsh
